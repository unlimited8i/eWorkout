from django.conf import settings
from django.db import models
from django.core.validators import EmailValidator , MinValueValidator


# Create your models here.



class Muscle(models.Model):
    muscle_name = models.CharField(max_length=255)

    #exercise_set
    def __str__(self) -> str:
        return self.muscle_name

class Equipment(models.Model):
    equipment_name =models.CharField(max_length=255)
    #exercises

    def __str__(self) -> str:
        return self.equipment_name

class Exercise(models.Model):
    TYPE_CHOICES =  [
        ('S','Strength'),
        ('A','Aerobic'),
        ('F','Flexibility')
    ]
    ex_name = models.CharField(max_length=255)
    description = models.TextField()
    slug = models.SlugField()
    image = models.ImageField(null = True, blank= True)
    ex_type = models.CharField(max_length=1,choices=TYPE_CHOICES,default='S')

    muscle = models.ForeignKey(Muscle,on_delete=models.CASCADE)
    equipment = models.ForeignKey(Equipment,on_delete=models.CASCADE,related_name = 'exercises')
    #frequency_set

    def __str__(self) -> str:
        return self.ex_name



class Trainer(models.Model):
    EXPERINCE_CHOICES = [
        ('B','Beginner'),
        ('I','Intermediate'),
        ('A','Advanced')
    ]
    IS_INJURED_CHOICES = [
        ('Y','Injured'),
        ('N','NotInjured'),
    ]
    GENDER_CHOICES = [
        ('M','Male'),
        ('F','Female'),
               

    ]
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True , null =True , blank= True)
    birth_date = models.DateField()
    gender = models.CharField(max_length=255,choices=GENDER_CHOICES,default='M' )
    is_Injured = models.CharField(max_length=1,choices=IS_INJURED_CHOICES,default='Y')
    experince=  models.CharField(max_length=1,choices=EXPERINCE_CHOICES,default='B')
    user = models.OneToOneField(settings.AUTH_USER_MODEL , on_delete = models.CASCADE)

    def __str__(self) -> str:
        return self.name
    
    class Meta:
        permissions = [
            ('injury_history' , 'Can view the injury history of the trainer'), #list the previous (if any) injuries of the trainer
            ('track_progress' , 'Can view the progress of the trainer'), # list that shows if the level of experince of the trainer has changed, ex: beginner -> advanced
        ]

class Schedule(models.Model):
    schedule_name= models.CharField(max_length=255)
    LEVEL_CHOICES = [
        ('B','Beginner'),
        ('I','Intermediate'),
        ('A','Advanced')
    ]
    level = models.CharField(max_length=1,choices=LEVEL_CHOICES,default='B')

    
    #session_set

    def __str__(self) -> str:
        return self.schedule_name

class Frequency(models.Model):
    repetitions = models.PositiveSmallIntegerField(validators=[MinValueValidator(1)])
    sets = models.PositiveSmallIntegerField(validators=[MinValueValidator(1)])

    exercise = models.ForeignKey(Exercise,on_delete=models.CASCADE)
    schedule = models.ForeignKey(Schedule,on_delete=models.CASCADE , related_name='frequencies')

    def __str__(self) -> str:
        return 'exercise name:'+str(self.exercise) + 'sets:' +str(self.sets) + ' rep:' +str(self.repetitions)
    
    class Meta:
        verbose_name_plural =('Frequencies')

class Session(models.Model):
    date = models.DateTimeField(auto_now_add=True)
    
    trainer =models.ForeignKey(Trainer, on_delete=models.CASCADE , related_name='sessions')
    schedule = models.ForeignKey(Schedule,on_delete=models.CASCADE)

    def __str__(self) -> str:
        return  'trainer name:'+str(self.trainer) +' schedule:' +str(self.schedule) +' date: ' +str(self.date)
    


