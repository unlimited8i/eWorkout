from django.urls import path,include
from rest_framework_nested import routers
from . import views


router = routers.DefaultRouter()
router.register('exercises',views.ExerciseViewSet)
router.register('schedules',views.ScheduleViewSet)
router.register('muscles',views.MuscleViewSet)
router.register('equipments',views.EquipmentViewSet)
router.register('trainers',views.TrainerViewSet)
router.register('frequencies',views.FrequencyViewSet)


#trainer_router =routers.NestedDefaultRouter(router, 'trainers',lookup = 'trainer')
router.register('sessions', views.SessionViewSet, basename='sessions')

urlpatterns = router.urls  #+ trainer_router.urls 

