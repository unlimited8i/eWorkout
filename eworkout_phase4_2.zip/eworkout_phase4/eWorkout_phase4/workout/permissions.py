from rest_framework import permissions
from .models import Trainer

class IsAdminOrReadOnly(permissions.BasePermission) :
    def has_permission(self, request, view):
        return bool (
            request.method in permissions.SAFE_METHODS
            or
            request.user
            and
            request.user.is_staff
        )
    
class CustomDjangoModelPermission (permissions.DjangoModelPermissions):
     perms_map = {
        'GET': ['%(app_label)s.view_%(model_name)s'],
        'OPTIONS': [],
        'HEAD': [],
        'POST': ['%(app_label)s.add_%(model_name)s'],
        'PUT': ['%(app_label)s.change_%(model_name)s'],
        'PATCH': ['%(app_label)s.change_%(model_name)s'],
        'DELETE': ['%(app_label)s.delete_%(model_name)s'],
    }
     
    
     

class TrainerInjuryHistory (permissions.BasePermission) :

    def has_permission(self, request, view):
        return request.user.has_perm('workout.injury_history')
    
class TrackTrainerProgress (permissions.BasePermission) :

    def has_permission(self, request, view):
        return request.user.has_perm('workout.track_progress')
    

    


 