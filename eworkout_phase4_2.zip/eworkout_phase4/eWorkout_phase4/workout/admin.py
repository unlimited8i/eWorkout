from typing import Any
from django.contrib import admin
from django.db.models.query import QuerySet
from django.utils.html import format_html, urlencode
from django.urls import reverse
from django.http.request import HttpRequest
from . import models
from django.db.models import Count,Q 


#to modify the default admin page:


class FrequencyInLine(admin.TabularInline):
    model = models.Frequency
    extra = 0
    min_num = 0
    autocomplete_fields = ['exercise']

@admin.register(models.Exercise)
class ExerciseAdmin(admin.ModelAdmin) :
    list_display = ['ex_name','muscle','description','equipment','ex_type']
    list_editable = ['description']
    list_per_page = 10
    list_select_related = True
    search_fields = ['ex_name__icontains']
    search_help_text = 'Enter the name of the exercise'
    list_filter = ['muscle','equipment','ex_type']
    fields = [
        ('ex_name','slug') , 'description',
        ('muscle' , 'equipment',) ,
        ('image' , 'ex_type') ,
    ]
    prepopulated_fields = {
        'slug' : ['ex_name']
    }
    inlines = [FrequencyInLine]




@admin.register(models.Trainer)
class TrainerAdmin (admin.ModelAdmin):
    list_display = ['name','gender','experince' ,'is_Injured' ,'injury' , 'session_count']
    list_editable =['is_Injured','experince']
    list_per_page = 20
    search_fields = ['name__icontains']
    search_help_text = 'Enter the name of the trainer'
    list_filter = ['gender','experince']


    @admin.display(ordering= 'count_session')
    def session_count(self, trainer:models.Trainer):
        return  trainer.count_session
    def get_queryset(self, request) :
        return super().get_queryset(request).annotate(
            count_session = Count('sessions')
        )


    @admin.display(ordering = 'is_Injured' , description = 'Ready' , boolean = True )
    def injury (self , trainer :models.Trainer) :
        if trainer.is_Injured == 'N' :
            return True
        else :
            return False
        
    
        


@admin.register(models.Schedule)
class ScheduleAdmin (admin.ModelAdmin):
    list_display = ['schedule_name','level','exercises' ]
    list_filter = ['level']
    search_fields = ['schedule_name__icontains']

    @admin.display(ordering= 'frequency__exercise__ex_name')
    def exercises (self , schedule) :
        queryset = models.Frequency.objects.filter(schedule_id = schedule.id).values_list('exercise__ex_name')
        exercise = ''
        for ex in queryset:
            for i in ex:
                exercise = exercise + i + ' , '
        return exercise

    inlines = [FrequencyInLine]

#custom filter for intensity
class IntensityFilter (admin.SimpleListFilter):
    title = 'intensity'
    parameter_name ='intensity'

    def lookups(self, request: Any, model_admin: Any) -> list[tuple[Any, str]]:
        return [
            ('<8','Low intensity') , ('>8and<12','Medium intenstiy') , ('>12' , 'High intensity')
        ]
  
    def queryset(self, request: Any, queryset: QuerySet[Any]) -> QuerySet[Any] | None:
        if self.value() == '<8':
            return queryset.filter(repetitions__lte =8) 
        if self.value() == '>8and<12':
            return queryset.filter(repetitions__gte =9 ,repetitions__lte=12)
        if self.value() == '>12':
            return queryset.filter(repetitions__gt =12) 


@admin.register(models.Frequency)
class FrequencyAdmin (admin.ModelAdmin):
    actions = ['low_intensity','medium_intensity','high_intensity']
    list_display = ['exercise','sets','repetitions','intenstiy']
    list_select_related = ['exercise']
    list_filter = [IntensityFilter]
    fields = [
        ('sets','repetitions') ,
        'exercise', 
        'schedule'
    ]

    autocomplete_fields = ['exercise']

    #action1
    @admin.action(description='make it low intensity')
    def low_intensity(self,request ,queryset=QuerySet):
        reps_up = queryset.filter(repetitions__gt =8).update(repetitions = 8)
        return self.message_user(request,f'{reps_up} exercises have been updated successfully')

    #action2
    @admin.action(description='make it medium  intensity')
    def medium_intensity(self,request ,queryset=QuerySet):
        reps_up = queryset.filter(Q(repetitions__lte =8) | Q(repetitions__gte =12) ).update(repetitions = 10)
        return self.message_user(request,f'{reps_up} exercises have been updated successfully')

    #action3
    @admin.action(description='make it high intensity')
    def high_intensity(self,request ,queryset=QuerySet):
        reps_up = queryset.filter(repetitions__lt =12).update(repetitions = 15)
        return self.message_user(request,f'{reps_up} exercises have been updated successfully')



    #to order intensity
    @admin.display(ordering='repetitions' , description= 'intensity')
    def intenstiy(self,frequency:models.Frequency):
        if ((frequency.repetitions <= 8)):
            return 'Low intenstiy'

        elif ( (frequency.repetitions <=12)):
            return 'Medium intenstiy'
        
        else:
            return 'High intensity'


@admin.register(models.Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ['trainer','schedule_schedule_name','date']
    list_select_related = ["trainer",'schedule']
    search_fields = ['trainer__name__icontains']
    search_help_text = 'Enter the name of the trainer'
    list_filter = ['schedule','date']
    autocomplete_fields = ['trainer','schedule']


    @admin.display(ordering='schedule__schedule_name' , description='session taken')
    def schedule_schedule_name(self,Session : models.Session):
        return Session.schedule.schedule_name


@admin.register(models.Muscle)
class MuscleAdmin(admin.ModelAdmin):
    list_display = ['muscle_name' , 'exercise_count']

    @admin.display(ordering='count_exercise' , description= 'exercises')
    # admin:app_mdel_page
    def exercise_count(self,muscle:models.Muscle):
        url =(
            reverse('admin:workout_exercise_changelist')
            +'?'
            +urlencode({
                'muscle__id':str(muscle.id)
            })
        )
        return format_html('<a href = "{}">{}</a>',url,muscle.count_exercise)
    
    def get_queryset(self, request: HttpRequest) -> QuerySet[Any]:
        return super().get_queryset(request).annotate(count_exercise =Count('exercise'))


@admin.register(models.Equipment)
class EquipmentAdmin(admin.ModelAdmin):
    list_display = ['equipment_name','equipment_exercise_count']


    @admin.display(ordering='count_equipment_exercise' , description= 'exercises')
    def equipment_exercise_count(self,equipment:models.Equipment):
        url =(
            reverse('admin:workout_exercise_changelist')
            +'?'
            +urlencode({
                'equipment__id':str(equipment.id)
            })
        )
        return format_html('<a href = "{}">{}</a>',url,equipment.count_equipment_exercise)
    
    def get_queryset(self, request: HttpRequest) -> QuerySet[Any]:
        return super().get_queryset(request).annotate(count_equipment_exercise =Count('exercises'))

# admin.site.register(models.Exercise,ExerciseAdmin)
# admin.site.register(models.Muscle)
# admin.site.register(models.Equipment)
# admin.site.register(models.Frequency,FrequencyAdmin)
# admin.site.register(models.Schedule,ScheduleAdmin)
# admin.site.register(models.Session,SessionAdmin)
# admin.site.register(models.Trainer,TrainerAdmin)