from django_filters.rest_framework import FilterSet
from .models import *

class FrequencyFilter(FilterSet):
    class Meta:
        model = Frequency
        fields = {
            'sets' : ['lte'],
            'repetitions': ['lte'],
            'schedule':['exact'],    
        }

class ExerciseFilter(FilterSet):
    class Meta:
        model = Exercise
        fields = {
            'ex_type':['exact'],
            'muscle':['exact'],
            'equipment':['exact']     
        }
class TrainerFilter(FilterSet):
    class Meta:
        model = Trainer
        fields = {
            'experince':['exact'],
            'gender':['exact'],
            'is_Injured':['exact']  
        }
class ScheduleFilter(FilterSet):
    class Meta:
        model = Schedule
        fields = {
            'level':['exact']
        }
        
class SessionFilter(FilterSet):
    class Meta:
        model = Session
        fields = {
            'schedule':['exact'],   
        }
