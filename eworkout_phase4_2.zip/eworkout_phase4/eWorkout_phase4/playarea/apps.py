from django.apps import AppConfig


class PlayareaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'playarea'
