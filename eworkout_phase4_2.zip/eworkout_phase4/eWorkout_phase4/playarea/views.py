from django.shortcuts import render
from django.http import HttpResponse
from workout.models import *
from django.db.models import Count
# Create your views here.



def web_page(request):
    queryset = Frequency.objects.filter(schedule = 1).values('exerciseex_name')
    list(queryset)
    ex = Exercise.objects.select_related('muscle').all().order_by('muscle__muscle_name')
    list(ex)
    return render(request,'playarea/index.html',
                        context={'ex':ex })