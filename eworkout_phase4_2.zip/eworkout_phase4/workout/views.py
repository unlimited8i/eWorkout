from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response 
from .models import *
from .serializers import *
from rest_framework.viewsets import ModelViewSet
from django.db.models import Count
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter,OrderingFilter
from rest_framework.pagination import PageNumberPagination ,LimitOffsetPagination
from .filters import *
from .paginations import DefaultPagination
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.mixins import CreateModelMixin, DestroyModelMixin,RetrieveModelMixin,UpdateModelMixin,ListModelMixin
from rest_framework.viewsets import GenericViewSet
from django.db.models import Count
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated , AllowAny , IsAdminUser , IsAuthenticatedOrReadOnly, DjangoModelPermissions
from .permissions import *



class ExerciseViewSet(ModelViewSet):
    queryset = Exercise.objects.select_related(
        'muscle','equipment').prefetch_related('frequency_set')
    serializer_class = ExerciseSerializer
    filterset_class = ExerciseFilter
    search_fields = ['ex_name']
    pagination_class = PageNumberPagination
    ordering_fields = ['ex_name','ex_type']
    permission_classes = [IsAdminOrReadOnly]
    

    def destroy(self,request, *args ,**kwargs):
        if Frequency.objects.filter(exercise_id = self.kwargs['pk']).count()>0:
            return Response({'error':'this Exercise is associated with a Frequency'},
                            status= status.HTTP_405_METHOD_NOT_ALLOWED)
        return super().destroy(request, *args , **kwargs)


class ScheduleViewSet(ModelViewSet):
    queryset = Schedule.objects.all().annotate(
        session_count = Count('session')).prefetch_related('frequencies')
    serializer_class = ScheduleSerializer
    filterset_class = ScheduleFilter
    search_fields = ['schedule_name']
    ordering_fields = ['session_count']
    permission_classes = [IsAdminOrReadOnly]
    

class SessionViewSet(CreateModelMixin, 
                      DestroyModelMixin,
                      RetrieveModelMixin,
                      ListModelMixin,GenericViewSet):
    
    serializer_class = SessionSerializer
    filterset_class = SessionFilter
    ordering_fields = ['date']
    permission_classes = [IsAdminUser]

    def get_queryset(self):
        user = self.request.user
        if self.request.user.is_staff :
            return Session.objects.all()
        trainer_id = Trainer.objects.only('id').get(user_id = user.id)
        return Session.objects.filter(trainer_id = trainer_id)

    # def get_serializer_context(self):
    #     return {'trainer_id':self.kwargs['trainer_pk']}
    

class MuscleViewSet(RetrieveModelMixin, 
                    ListModelMixin,
                    GenericViewSet):
    queryset = Muscle.objects.prefetch_related('exercise_set').all()
    serializer_class = MuscleSerializer
    search_fields = ['muscle_name']
    pagination_class = DefaultPagination
    ordering_fields = ['muscle_name']
    permission_classes = [IsAdminOrReadOnly]


    
class EquipmentViewSet(CreateModelMixin, 
                      DestroyModelMixin,
                      RetrieveModelMixin,
                      ListModelMixin,GenericViewSet):
    queryset = Equipment.objects.prefetch_related('exercises').all()
    serializer_class = EquipmentSerializer
    search_fields = ['equipment_name']
    pagination_class = DefaultPagination
    ordering_fields = ['equipment_name']
    permission_classes = [IsAdminOrReadOnly]

    # overriding the destroy method
    def destroy(self,request, *args ,**kwargs):
        if Exercise.objects.filter(equipment_id = self.kwargs['pk']).count()>0:
            return Response({'error':'this Equipment is associated with exercises'},
                            status= status.HTTP_405_METHOD_NOT_ALLOWED)
        return super().destroy(request, *args , **kwargs)

    


class TrainerViewSet(ModelViewSet):
    queryset = Trainer.objects.all().prefetch_related('sessions')
    serializer_class = TrainerSerializer
    filterset_class = TrainerFilter
    search_fields = ['name']
    ordering_fields = ['name','experince']
    permission_classes = [CustomDjangoModelPermission]


    @action(detail = False , methods = ['GET' , 'PUT' , 'DELETE' ])
    def me(self, request):
        trainer = Trainer.objects.get(user_id = request.user.id)
        if request.method == 'GET' :
            serializer = TrainerSerializer(trainer)
            return Response(serializer.data)
        elif request.method == 'PUT' :
            serializer = TrainerSerializer(trainer , data = request.data)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)
        elif request.method == 'DELETE':
            trainer = Trainer.objects.get(user_id = request.user.id)
            trainer.user.delete()
            trainer.delete()
            return Response('your account has been deleted',status = status.HTTP_204_NO_CONTENT)
        

    @action(detail=True, permission_classes = [TrainerInjuryHistory])    
    def injury_history(self, request, pk):
        return Response('not implemented')
    
    @action(detail=True, permission_classes =[TrackTrainerProgress])    
    def track_progress(self, request, pk):
        return Response('not implemented (hopefully the trainer is making some progress :) ')
    
    




    # def get_permissions(self):
        
    #     if self.request.method == 'GET':
           
    #         return [AllowAny()]
        
        
    #     return [IsAdminUser()]
       
    



class FrequencyViewSet(ModelViewSet):
    queryset = Frequency.objects.all().select_related('schedule')
    serializer_class = FrequencySerializer
    filterset_class = FrequencyFilter
    ordering_fields = ['sets','repetitions']
    permission_classes = [IsAdminOrReadOnly]
