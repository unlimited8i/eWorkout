from rest_framework import serializers
from .models import *


class ExerciseSerializer(serializers.ModelSerializer):

    exercise_name = serializers.CharField(max_length=255 
                                                 ,source = 'ex_name')
    muscle = serializers.HyperlinkedRelatedField(
        queryset=Muscle.objects.all(),
        view_name='muscle-detail'
    )

    class Meta:
        model = Exercise
        fields = ['id','exercise_name', 'description','ex_type','muscle','equipment']


class SummerizedFrequencySerializer(serializers.ModelSerializer):
    exercise = serializers.HyperlinkedRelatedField(
        queryset=Exercise.objects.all(),
        view_name='exercise-detail'
    )
    class Meta:
        model = Frequency
        fields = ['id','exercise','sets','repetitions']

class ScheduleSerializer(serializers.ModelSerializer):
    session_count = serializers.IntegerField(read_only = True)
    exercises = SummerizedFrequencySerializer(many=True, read_only=True, source='frequencies')
    class Meta:
        model = Schedule
        fields = ['id','schedule_name', 'exercises','level' , 'session_count' ]


class SessionSerializer(serializers.ModelSerializer):
    def create(self, validated_data):
        return Session.objects.create(trainer_id = self.context['trainer_id'],
                                    **validated_data)
    
    trainer = serializers.StringRelatedField()
    class Meta:
        model = Session
        fields = ['id','trainer','date','schedule']


class MuscleSerializer(serializers.ModelSerializer):
    exercises = serializers.StringRelatedField(
        many = True , source= 'exercise_set', read_only = True)
    class Meta:
        model = Muscle
        fields = ['id','muscle_name','exercises']


class EquipmentSerializer(serializers.ModelSerializer):
    exercises_used = serializers.StringRelatedField(
        many = True , source= 'exercises', read_only = True)
    class Meta:
        model = Equipment
        fields = ['id','equipment_name','exercises_used']


class TrainerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trainer
        fields = ['id','name','email','birth_date','is_Injured','gender','experince']



class FrequencySerializer(serializers.ModelSerializer):
    schedule = serializers.HyperlinkedRelatedField(
    queryset=Schedule.objects.all(),
    view_name='schedule-detail')

    exercise = serializers.HyperlinkedRelatedField(
    queryset=Exercise.objects.all(),
    view_name='exercise-detail')
    
    total_repetitions = serializers.SerializerMethodField(
        method_name='get_total_repetitions')

    def get_total_repetitions(self,frequency:Frequency):
        return frequency.repetitions * frequency.sets

    class Meta:
        model = Frequency
        fields = ['id','schedule','exercise','sets','repetitions','total_repetitions']

