CREATE DATABASE  IF NOT EXISTS `eworkoutproject1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `eworkoutproject1`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: eworkoutproject1
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_user`
--

DROP TABLE IF EXISTS `account_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_user`
--

LOCK TABLES `account_user` WRITE;
/*!40000 ALTER TABLE `account_user` DISABLE KEYS */;
INSERT INTO `account_user` VALUES (1,'pbkdf2_sha256$720000$vaFsfvYqESPbZhFupgoKZb$Zkg3tLPtpzrRcjV4AW+c6ki4sOhzIUvpk3elzH2kuqU=','2024-01-03 15:54:20.875538',1,'admin','','','eWorkout@gmail.com',1,1,'2023-11-09 09:55:16.773817'),(2,'pbkdf2_sha256$720000$kIXyGR6iCTyfGN0SGuDzfa$v7tOt44SSqszVptLDhlsw9wqFjTIteH5BaD63hREy2Q=','2024-01-03 15:30:21.231901',0,'user1','','','',1,1,'2024-01-02 18:18:59.000000'),(3,'pbkdf2_sha256$720000$MvjdhjTrytnhAZXBd9xos9$n/HeKziTSwLJ6YfeZ67VNukTDCX4Kvnb51t8isIEzoE=','2024-01-03 15:31:29.865157',0,'user2','','','',1,1,'2024-01-02 18:21:34.000000'),(5,'pbkdf2_sha256$720000$AOFMharDXGuJ3qynauIzDh$WIfiMybPqRclcJ/Y4+OFzKjlcJIPtB3/MU4jqP+zjs0=',NULL,0,'user3','','','',0,1,'2024-01-02 18:54:41.543479');
/*!40000 ALTER TABLE `account_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_user_groups`
--

DROP TABLE IF EXISTS `account_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_user_groups_user_id_group_id_4d09af3e_uniq` (`user_id`,`group_id`),
  KEY `account_user_groups_group_id_6c71f749_fk_auth_group_id` (`group_id`),
  CONSTRAINT `account_user_groups_group_id_6c71f749_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `account_user_groups_user_id_14345e7b_fk_account_user_id` FOREIGN KEY (`user_id`) REFERENCES `account_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_user_groups`
--

LOCK TABLES `account_user_groups` WRITE;
/*!40000 ALTER TABLE `account_user_groups` DISABLE KEYS */;
INSERT INTO `account_user_groups` VALUES (1,2,1);
/*!40000 ALTER TABLE `account_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_user_user_permissions`
--

DROP TABLE IF EXISTS `account_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_user_user_permis_user_id_permission_id_48bdd28b_uniq` (`user_id`,`permission_id`),
  KEY `account_user_user_pe_permission_id_66c44191_fk_auth_perm` (`permission_id`),
  CONSTRAINT `account_user_user_pe_permission_id_66c44191_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `account_user_user_pe_user_id_cc42d270_fk_account_u` FOREIGN KEY (`user_id`) REFERENCES `account_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_user_user_permissions`
--

LOCK TABLES `account_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `account_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
INSERT INTO `auth_group` VALUES (3,'Equipment Service'),(6,'Session service'),(1,'Trainer service'),(5,'Workout Modifing'),(2,'Workout service');
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
INSERT INTO `auth_group_permissions` VALUES (2,1,37),(3,1,38),(4,1,39),(1,1,40),(48,1,61),(49,1,62),(19,2,29),(20,2,30),(21,2,31),(9,2,32),(10,2,33),(11,2,34),(12,2,35),(13,2,36),(47,2,54),(14,2,56),(15,2,57),(16,2,58),(17,2,59),(18,2,60),(6,3,53),(7,3,54),(8,3,55),(5,3,56),(46,5,30),(37,5,32),(38,5,34),(39,5,36),(40,5,50),(41,5,52),(42,5,54),(43,5,56),(44,5,58),(45,5,60),(32,6,40),(33,6,41),(34,6,42),(35,6,43),(36,6,44);
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add user',6,'add_user'),(22,'Can change user',6,'change_user'),(23,'Can delete user',6,'delete_user'),(24,'Can view user',6,'view_user'),(25,'Can add category',7,'add_category'),(26,'Can change category',7,'change_category'),(27,'Can delete category',7,'delete_category'),(28,'Can view category',7,'view_category'),(29,'Can add exercise',8,'add_exercise'),(30,'Can change exercise',8,'change_exercise'),(31,'Can delete exercise',8,'delete_exercise'),(32,'Can view exercise',8,'view_exercise'),(33,'Can add schedule',9,'add_schedule'),(34,'Can change schedule',9,'change_schedule'),(35,'Can delete schedule',9,'delete_schedule'),(36,'Can view schedule',9,'view_schedule'),(37,'Can add trainer',10,'add_trainer'),(38,'Can change trainer',10,'change_trainer'),(39,'Can delete trainer',10,'delete_trainer'),(40,'Can view trainer',10,'view_trainer'),(41,'Can add session',11,'add_session'),(42,'Can change session',11,'change_session'),(43,'Can delete session',11,'delete_session'),(44,'Can view session',11,'view_session'),(45,'Can add musle',12,'add_musle'),(46,'Can change musle',12,'change_musle'),(47,'Can delete musle',12,'delete_musle'),(48,'Can view musle',12,'view_musle'),(49,'Can add frequency',13,'add_frequency'),(50,'Can change frequency',13,'change_frequency'),(51,'Can delete frequency',13,'delete_frequency'),(52,'Can view frequency',13,'view_frequency'),(53,'Can add equipment',14,'add_equipment'),(54,'Can change equipment',14,'change_equipment'),(55,'Can delete equipment',14,'delete_equipment'),(56,'Can view equipment',14,'view_equipment'),(57,'Can add muscle',12,'add_muscle'),(58,'Can change muscle',12,'change_muscle'),(59,'Can delete muscle',12,'delete_muscle'),(60,'Can view muscle',12,'view_muscle'),(61,'can view the injury history for the trainer',10,'injury_history'),(62,'can view the progress of the trainer',10,'track_progress');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_account_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_account_user_id` FOREIGN KEY (`user_id`) REFERENCES `account_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2023-11-09 10:19:55.312840','13','Schedule object (13)',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(2,'2023-11-09 10:51:22.769740','50','Evangelin Bickersteth',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(3,'2023-11-09 10:51:54.263067','18','Ashia Witnall',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(4,'2023-11-09 10:53:21.001701','44','Aluin Dellenty',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(5,'2023-11-09 10:53:21.003636','37','Jourdain Tarte',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(6,'2023-11-09 10:53:21.003636','35','Kelby Drummond',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(7,'2023-11-09 10:53:21.003636','49','Elwood Dolligon',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(8,'2023-11-09 10:53:21.003636','45','Harlin Gleave',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(9,'2023-11-09 10:53:21.003636','42','Barret Whitsey',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(10,'2023-11-09 10:53:21.012824','34','Levin Falloon',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(11,'2023-11-09 10:53:21.013299','33','Keenan Prout',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(12,'2023-11-09 10:53:21.013299','32','Eugine Ickovitz',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(13,'2023-11-09 10:53:21.013299','30','Hubie Briamo',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(14,'2023-11-09 10:53:21.013299','27','Wash Roly',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(15,'2023-11-09 10:53:21.013299','26','Coop Bagger',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(16,'2023-11-09 10:53:21.021373','23','Brantley Dominiak',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(17,'2023-11-09 10:53:21.021373','22','Maxy Escala',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(18,'2023-11-09 10:53:21.021373','20','Isador Moat',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(19,'2023-11-09 10:53:21.021373','19','Haywood Phippen',2,'[{\"changed\": {\"fields\": [\"Is Injured\", \"Gender\"]}}]',10,1),(20,'2023-11-09 10:53:21.021373','17','Dom Ledgard',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(21,'2023-11-09 10:53:21.021373','14','Keelby Niemiec',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(22,'2023-11-09 10:53:21.021373','13','Hank Rhymes',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(23,'2023-11-09 10:53:21.029627','12','Teador Dally',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(24,'2023-11-09 10:53:40.597335','9','Ingelbert Elegood',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(25,'2023-11-09 10:53:40.597335','8','Ellsworth Stockdale',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(26,'2023-11-09 10:53:40.597335','5','Dominik Seamans',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(27,'2023-11-09 10:53:40.597335','4','Baxy Toman',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(28,'2023-11-09 10:53:40.605337','2','Baldwin Madine',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(29,'2023-11-09 10:53:40.605337','1','Roman Carlow',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(30,'2023-11-09 10:54:42.413920','38','Arley Dryland',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(31,'2023-11-09 10:54:42.423272','16','Bil Burgis',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(32,'2023-11-09 10:54:42.423272','48','Georgette Gathwaite',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(33,'2023-11-09 10:54:42.423272','47','Alene Keggin',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(34,'2023-11-09 10:54:42.423272','46','Blondell Sheldrake',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(35,'2023-11-09 10:54:42.423272','43','Carmella Dukelow',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(36,'2023-11-09 10:54:42.423272','41','Jocelin Calcutt',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(37,'2023-11-09 10:54:42.431273','40','Camila Winks',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(38,'2023-11-09 10:54:42.431273','39','Hedy McPhelimy',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(39,'2023-11-09 10:54:42.431273','36','Nelia Hazelwood',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(40,'2023-11-09 10:54:42.431273','31','Walliw Bullion',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(41,'2023-11-09 10:54:42.431273','29','Harrietta Londing',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(42,'2023-11-09 10:54:42.431273','28','Cecil Tunniclisse',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(43,'2023-11-09 10:54:42.439872','25','Crista Devenish',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(44,'2023-11-09 10:55:00.490211','24','Anna Conquest',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(45,'2023-11-09 10:55:00.490211','21','Inger Aizikov',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(46,'2023-11-09 10:55:00.490211','15','Zsazsa Timmes',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(47,'2023-11-09 10:55:00.490211','11','Clemmie Ockenden',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(48,'2023-11-09 10:55:00.499744','10','Margaretha Mulran',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(49,'2023-11-09 10:55:00.499744','7','Ingaborg Totaro',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(50,'2023-11-09 10:55:00.499744','6','Sharline Morton',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(51,'2023-11-09 10:55:00.499744','3','Yolanthe Berriball',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}]',10,1),(52,'2023-11-10 11:58:25.984784','37','KETTLEBELL_SINGLE_ARM_ROW',2,'[{\"changed\": {\"fields\": [\"Descreption\"]}}]',8,1),(53,'2023-11-10 11:58:25.987857','50','DUMBBELL_TWISTING_CURL',2,'[{\"changed\": {\"fields\": [\"Descreption\"]}}]',8,1),(54,'2023-11-10 12:00:52.452840','12','Advanced Dumbell Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(55,'2023-11-10 12:01:54.420687','10','Intermediate Triceps Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(56,'2023-11-10 12:02:41.425942','9','Intermediate Band Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(57,'2023-11-10 12:03:06.586805','8','Intermediate Cable Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(58,'2023-11-10 12:03:30.033736','7','Intermediate Barbell Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(59,'2023-11-10 12:03:54.413433','11','Advanced Kettlebell Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(60,'2023-11-10 12:05:10.736513','6','Beginner Bodyweight Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(61,'2023-11-10 12:05:49.370736','4','Beginner Dumbbell Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(62,'2023-11-10 12:05:56.876660','12','Advanced Dumbbell Workout',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(63,'2023-11-10 12:07:41.954660','5','Upper Body For Women',2,'[{\"changed\": {\"fields\": [\"Schedule name\"]}}]',9,1),(64,'2023-11-10 12:34:05.978955','1','WALK_THE_HILLS',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(65,'2023-11-10 12:34:05.981948','17','SUPERMANS',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(66,'2023-11-10 12:34:05.984939','52','Plate car drive',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(67,'2023-11-10 12:34:05.986941','35','KETTLEBELL_SKULL_CRUSHER',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(68,'2023-11-10 12:34:05.989933','37','KETTLEBELL_SINGLE_ARM_ROW',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(69,'2023-11-10 12:34:05.992925','36','KETTLEBELL_REVERSE_LUNGE',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(70,'2023-11-10 12:34:05.995526','38','KETTLEBELL_CONCENTRATION_CURL',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(71,'2023-11-10 12:34:05.998509','2','INTERVAL_TRAINING',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(72,'2023-11-10 12:34:06.000503','18','GLUTE_BRIDGE',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(73,'2023-11-10 12:41:21.182953','50','DUMBBELL_TWISTING_CURL',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(74,'2023-11-10 12:41:21.185571','51','DUMBBELL_SKULLCRUSHER',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(75,'2023-11-10 12:41:21.187560','7','DUMBBELL_ROW_BILATERAL',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(76,'2023-11-10 12:41:21.190553','48','DUMBBELL_ROMANIAN_DEADLIFT',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(77,'2023-11-10 12:41:21.192547','33','DUMBBELL_OVERHEAD_TRICEP_EXTENSION',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(78,'2023-11-10 12:41:21.194543','9','DUMBBELL_OVERHEAD_PRESS',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(79,'2023-11-10 12:41:21.197535','46','DUMBBELL_LAYING_REVERSE_FLY',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(80,'2023-11-10 12:41:21.199529','47','DUMBBELL_LATERAL_RAISE',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(81,'2023-11-10 12:41:21.202522','6','DUMBBELL_GOBLET_SQUAT',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(82,'2023-11-10 12:41:21.204516','8','DUMBBELL_FORWARD_LUNGE',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(83,'2023-11-10 12:41:21.206812','49','DUMBBELL_CALF_RAISE',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(84,'2023-11-10 12:41:21.208808','45','DUMBBELL_BULGARIAN_SPLIT_SQUAT',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(85,'2023-11-10 12:41:21.211800','11','DUMBBELL_BENCH_PRESS',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(86,'2023-11-10 12:41:21.213794','13','DUMBBELL_ARNOLD_PRESS',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(87,'2023-11-10 12:41:21.216372','16','DECLINE_PUSH_UP',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(88,'2023-11-10 12:41:21.219364','27','CABLE_PEC_FLY',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(89,'2023-11-10 12:41:21.221358','10','CABLE_LAT_PRAYER',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(90,'2023-11-10 12:41:21.223353','29','CABLE_HAMSTRING_CURL',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(91,'2023-11-10 12:41:21.226331','34','CABLE_CROSS_PUSHDOWN',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(92,'2023-11-10 12:41:21.228319','26','CABLE_BENTOVER_BAR_PULLOVER',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(93,'2023-11-10 12:41:21.231310','28','CABLE_30DEGREE_SHRUG',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(94,'2023-11-10 12:41:21.233304','14','BODYWEIGHT_REVERSE_LUNGE',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(95,'2023-11-10 12:41:21.235686','41','BARBELL_UPRIGHT_ROW',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(96,'2023-11-10 12:41:21.237666','32','BAND_SINGLE_ARM_OVERHEAD_PRESS',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(97,'2023-11-10 12:41:21.240652','30','BAND_PULLOVER',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(98,'2023-11-10 12:41:21.242646','12','BAND_PULL_APART',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(99,'2023-11-10 12:41:21.245248','31','BAND_CRUNCH',2,'[{\"changed\": {\"fields\": [\"Equipment\"]}}]',8,1),(102,'2023-11-10 13:41:42.644971','50','Evangelin Bickersteth',2,'[{\"changed\": {\"fields\": [\"Is Injured\"]}}]',10,1),(103,'2023-11-10 13:41:42.647378','49','Elwood Dolligon',2,'[{\"changed\": {\"fields\": [\"Is Injured\"]}}]',10,1),(104,'2023-11-10 13:41:56.869987','47','Alene Keggin',2,'[{\"changed\": {\"fields\": [\"Is Injured\"]}}]',10,1),(105,'2023-11-10 13:41:56.871982','43','Carmella Dukelow',2,'[{\"changed\": {\"fields\": [\"Is Injured\"]}}]',10,1),(106,'2023-11-10 14:07:56.797435','51','Hans Zimmer',1,'[{\"added\": {}}]',10,1),(107,'2023-11-10 15:00:55.220430','15','2023-11-10 15:00:55.218435+00:00',1,'[{\"added\": {}}]',11,1),(108,'2023-11-14 14:58:05.843606','15','Rope',1,'[{\"added\": {}}]',14,1),(109,'2023-11-14 15:00:00.433259','57','sets:3 rep:3',1,'[{\"added\": {}}]',13,1),(110,'2024-01-02 17:47:14.031228','52','test',1,'[{\"added\": {}}]',10,1),(111,'2024-01-02 18:05:27.544332','21','trainer name:test schedule:Intermediate Triceps Workout date: 2024-01-02 18:05:27.544332+00:00',1,'[{\"added\": {}}]',11,1),(112,'2024-01-02 18:09:21.450958','1','Trainer service',1,'[{\"added\": {}}]',3,1),(113,'2024-01-02 18:11:45.629090','2','Workout service',1,'[{\"added\": {}}]',3,1),(114,'2024-01-02 18:12:27.251468','3','Equipment Service',1,'[{\"added\": {}}]',3,1),(115,'2024-01-02 18:14:40.632258','2','Workout service',2,'[{\"changed\": {\"fields\": [\"Permissions\"]}}]',3,1),(116,'2024-01-02 18:18:21.273389','4','Trainer permissions',1,'[{\"added\": {}}]',3,1),(117,'2024-01-02 18:18:59.760230','2','user1',1,'[{\"added\": {}}]',6,1),(118,'2024-01-02 18:20:07.946146','2','user1',2,'[{\"changed\": {\"fields\": [\"Staff status\", \"Groups\"]}}]',6,1),(119,'2024-01-02 18:20:41.299914','4','Trainer permissions',3,'',3,1),(120,'2024-01-02 18:21:34.561523','3','user2',1,'[{\"added\": {}}]',6,1),(121,'2024-01-02 18:21:58.525103','3','user2',2,'[{\"changed\": {\"fields\": [\"Staff status\"]}}]',6,1),(122,'2024-01-02 18:22:18.947775','4','user3',1,'[{\"added\": {}}]',6,1),(123,'2024-01-02 18:22:23.849333','4','user3',2,'[]',6,1),(124,'2024-01-02 18:47:17.043632','4','user3',2,'[]',6,1),(125,'2024-01-02 18:54:22.285019','4','user3',3,'',6,1),(126,'2024-01-02 18:54:41.905184','5','user3',1,'[{\"added\": {}}]',6,1),(127,'2024-01-02 18:57:12.557122','5','Workout Modifing',1,'[{\"added\": {}}]',3,1),(128,'2024-01-02 18:58:16.301394','6','Session service',1,'[{\"added\": {}}]',3,1),(129,'2024-01-02 18:59:05.519430','5','Workout Modifing',2,'[{\"changed\": {\"fields\": [\"Permissions\"]}}]',3,1),(130,'2024-01-02 20:32:12.473652','53','Abdullah',1,'[{\"added\": {}}]',10,1),(131,'2024-01-03 08:25:43.007914','2','Workout service',2,'[{\"changed\": {\"fields\": [\"Permissions\"]}}]',3,1),(132,'2024-01-03 09:02:03.488731','54','Ahmad',1,'[{\"added\": {}}]',10,1),(133,'2024-01-03 14:14:42.361803','52','test',2,'[{\"changed\": {\"fields\": [\"User\"]}}]',10,1),(134,'2024-01-03 14:14:59.848892','52','test',2,'[]',10,1),(135,'2024-01-03 14:15:13.712060','21','trainer name:test schedule:Intermediate Triceps Workout date: 2024-01-02 18:05:27.544332+00:00',2,'[]',11,1),(136,'2024-01-03 15:05:21.589567','22','trainer name:Abdullah schedule:CARDIO date: 2024-01-03 15:05:21.589567+00:00',1,'[{\"added\": {}}]',11,1),(137,'2024-01-03 15:10:49.380014','7','test55',1,'[{\"added\": {}}]',6,1),(138,'2024-01-03 15:11:16.140872','55','test55',1,'[{\"added\": {}}]',10,1),(139,'2024-01-03 15:11:26.133100','23','trainer name:test55 schedule:STRETHCHES date: 2024-01-03 15:11:26.133100+00:00',1,'[{\"added\": {}}]',11,1),(140,'2024-01-03 15:58:06.206863','1','Trainer service',2,'[{\"changed\": {\"fields\": [\"Permissions\"]}}]',3,1),(141,'2024-01-03 17:28:03.202334','6','test2',2,'[{\"changed\": {\"fields\": [\"Groups\"]}}]',6,1),(142,'2024-01-03 17:31:08.661716','56','tes2',1,'[{\"added\": {}}]',10,1),(143,'2024-01-03 17:32:04.371305','56','tes2',3,'',10,1),(144,'2024-01-03 17:32:12.875012','6','test2',3,'',6,1),(145,'2024-01-04 18:21:22.013389','24','trainer name:Ahmad schedule:Advanced Kettlebell Workout date: 2024-01-04 18:21:22.005326+00:00',1,'[{\"added\": {}}]',11,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (6,'account','user'),(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'contenttypes','contenttype'),(5,'sessions','session'),(7,'workout','category'),(14,'workout','equipment'),(8,'workout','exercise'),(13,'workout','frequency'),(12,'workout','muscle'),(9,'workout','schedule'),(11,'workout','session'),(10,'workout','trainer');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-10-22 18:50:24.462685'),(2,'contenttypes','0002_remove_content_type_name','2023-10-22 18:50:24.491608'),(3,'auth','0001_initial','2023-10-22 18:50:24.590344'),(4,'auth','0002_alter_permission_name_max_length','2023-10-22 18:50:24.615277'),(5,'auth','0003_alter_user_email_max_length','2023-10-22 18:50:24.621261'),(6,'auth','0004_alter_user_username_opts','2023-10-22 18:50:24.626248'),(7,'auth','0005_alter_user_last_login_null','2023-10-22 18:50:24.630238'),(8,'auth','0006_require_contenttypes_0002','2023-10-22 18:50:24.634227'),(9,'auth','0007_alter_validators_add_error_messages','2023-10-22 18:50:24.640211'),(10,'auth','0008_alter_user_username_max_length','2023-10-22 18:50:24.644200'),(11,'auth','0009_alter_user_last_name_max_length','2023-10-22 18:50:24.649186'),(12,'auth','0010_alter_group_name_max_length','2023-10-22 18:50:24.660157'),(13,'auth','0011_update_proxy_permissions','2023-10-22 18:50:24.665144'),(14,'auth','0012_alter_user_first_name_max_length','2023-10-22 18:50:24.671138'),(15,'account','0001_initial','2023-10-22 18:50:24.792803'),(16,'admin','0001_initial','2023-10-22 18:50:24.858627'),(17,'admin','0002_logentry_remove_auto_add','2023-10-22 18:50:24.865608'),(18,'admin','0003_logentry_add_action_flag_choices','2023-10-22 18:50:24.871592'),(19,'sessions','0001_initial','2023-10-22 18:50:24.891538'),(20,'workout','0001_initial','2023-10-22 18:50:25.113983'),(21,'workout','0002_alter_trainer_experince','2023-10-22 18:52:41.999793'),(22,'workout','0003_rename_musle_muscle_rename_musle_exercise_muscle_and_more','2023-10-24 10:25:57.528557'),(23,'workout','0004_rename_group_of_muscles_schedule_schedule_name_and_more','2023-10-26 12:30:16.728907'),(24,'workout','0005_rename_repetitons_frequency_repetitions','2023-10-26 12:41:27.029946'),(25,'workout','0006_rename_discreption_exercise_descreption','2023-10-26 13:31:41.595507'),(26,'workout','0007_remove_equipment_category_remove_muscle_category_and_more','2023-11-09 09:03:40.841904'),(27,'workout','0008_exercise_equipment','2023-11-09 09:40:37.699661'),(30,'workout','0009_exercise_ex_type','2023-11-09 09:47:31.915796'),(31,'workout','0010_rename_health_status_trainer_is_injured','2023-11-09 10:14:22.600030'),(32,'workout','0011_alter_frequency_repetitions_alter_frequency_sets','2023-11-09 10:28:46.093416'),(33,'workout','0012_alter_trainer_gender','2023-11-09 10:55:25.631640'),(34,'workout','0013_alter_trainer_gender','2023-11-10 11:46:28.975456'),(35,'workout','0014_alter_exercise_equipment_alter_exercise_image','2023-11-13 16:15:21.382481'),(36,'workout','0015_alter_trainer_email','2023-11-13 16:15:21.436345'),(37,'workout','0016_alter_frequency_repetitions_alter_frequency_sets','2023-11-13 16:17:13.122368'),(38,'workout','0017_alter_session_date','2023-11-13 16:17:30.510900'),(39,'workout','0018_rename_descreption_exercise_description','2023-11-13 17:16:10.283290'),(40,'workout','0019_alter_frequency_options','2023-11-14 15:03:21.130268'),(41,'workout','0020_alter_trainer_email','2023-12-07 23:21:06.423617'),(42,'workout','0021_alter_session_trainer','2023-12-13 03:01:16.870488'),(43,'workout','0022_alter_frequency_schedule','2023-12-13 05:09:45.455083'),(44,'workout','0023_trainer_user','2024-01-02 17:43:27.128077'),(45,'workout','0024_alter_session_options','2024-01-02 17:43:27.143701'),(46,'workout','0025_alter_session_options','2024-01-02 17:43:27.143701'),(47,'workout','0026_alter_trainer_options','2024-01-03 15:51:48.812211'),(48,'workout','0027_alter_trainer_options','2024-01-03 15:53:43.893896'),(49,'workout','0028_alter_trainer_options','2024-01-03 15:56:22.021788'),(50,'workout','0029_alter_trainer_options','2024-01-03 15:56:47.938562');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('1xlq320p9zzx062r1zjgenxvlh9l1gj3','.eJxVjDsOwjAQRO_iGllxMFaWkp4zWPszDiBHipMq4u44UgooZ96b2UzEdclxrTrHUczVOHP67Qj5pWUH8sTymCxPZZlHsrtiD1rtfRJ93w737yBjzW09AA59rwHUh6BJBRhSEOFLQgwYzuA7RCCgJnkGakGUqPMO2YMzny8Nvjk0:1rL3ZU:5cFWTBN0OigGpYEayCFAAykbA-7WClGnAAjQfD__C14','2024-01-17 15:54:20.879910'),('a6msrdefgjo015y4ru1kzbskhxs14u9p','.eJxVjEsOAiEQBe_C2hBooG1duvcMhE8jowaSYWZlvLtOMgvdvqp6L-HDulS_Dp79lMVZaHH43WJID24byPfQbl2m3pZ5inJT5E6HvPbMz8vu_h3UMOq3RmAswDprZZEpA4HTFhUpgyeroKgjFACwxAZiMZGs0to5tJEcJBTvD6N-NeQ:1rBMxg:Z14asvWpKP7_bVCQCLDjYNGTv0JBIUOF15s3-K5e6h8','2023-12-21 22:35:16.910753'),('b9w6f28zd3b47j4fu5n9m3vpiwltvo7t','.eJxVjEsOAiEQBe_C2hBooG1duvcMhE8jowaSYWZlvLtOMgvdvqp6L-HDulS_Dp79lMVZaHH43WJID24byPfQbl2m3pZ5inJT5E6HvPbMz8vu_h3UMOq3RmAswDprZZEpA4HTFhUpgyeroKgjFACwxAZiMZGs0to5tJEcJBTvD6N-NeQ:1r11mg:Y5t7X8_K-U9Mw0XQeI68X3exEJTjzl1_Kl8E6UyZkqI','2023-11-23 09:57:10.748045'),('gf4dbgzo6sutxxbgme92bxfdcwkseqeh','.eJxVjEsOAiEQBe_C2hBooG1duvcMhE8jowaSYWZlvLtOMgvdvqp6L-HDulS_Dp79lMVZaHH43WJID24byPfQbl2m3pZ5inJT5E6HvPbMz8vu_h3UMOq3RmAswDprZZEpA4HTFhUpgyeroKgjFACwxAZiMZGs0to5tJEcJBTvD6N-NeQ:1r2Vnz:bxF44Ru4d2AGO_9llQTDhIVWypuPSbSSqJYu0Mfotzc','2023-11-27 12:12:39.110602');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_equipment`
--

DROP TABLE IF EXISTS `workout_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_equipment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `equipment_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_equipment`
--

LOCK TABLES `workout_equipment` WRITE;
/*!40000 ALTER TABLE `workout_equipment` DISABLE KEYS */;
INSERT INTO `workout_equipment` VALUES (1,'BARBELL'),(2,'DUMBBELLS'),(3,'CABLE'),(4,'PLATE'),(5,'KETTLEBELLS'),(6,'BAND'),(7,'MACHINE'),(8,'BODYWEIGHT'),(9,'JUMP_ROPE'),(10,'TREADMILL'),(11,'STAIRSTEPPER'),(12,'STATIONARY_BIKE'),(13,'STRETHCHES'),(14,'YOGA'),(15,'Rope');
/*!40000 ALTER TABLE `workout_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_exercise`
--

DROP TABLE IF EXISTS `workout_exercise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_exercise` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ex_name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `slug` varchar(50) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `muscle_id` bigint NOT NULL,
  `equipment_id` bigint NOT NULL,
  `ex_type` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workout_exercise_slug_5d2ecfc9` (`slug`),
  KEY `workout_exercise_muscle_id_aa7d262a_fk_workout_muscle_id` (`muscle_id`),
  KEY `workout_exercise_equipment_id_189b6f08_fk_workout_muscle_id` (`equipment_id`),
  CONSTRAINT `workout_exercise_equipment_id_189b6f08_fk_workout_equipment_id` FOREIGN KEY (`equipment_id`) REFERENCES `workout_equipment` (`id`),
  CONSTRAINT `workout_exercise_muscle_id_aa7d262a_fk_workout_muscle_id` FOREIGN KEY (`muscle_id`) REFERENCES `workout_muscle` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_exercise`
--

LOCK TABLES `workout_exercise` WRITE;
/*!40000 ALTER TABLE `workout_exercise` DISABLE KEYS */;
INSERT INTO `workout_exercise` VALUES (1,'WALK_THE_HILLS','SET AN INCLINE FOR THE TREADMILL FOR A MORE EFFECTIVE WAY TO BURN CALORIES.','-','',10,10,'S'),(2,'INTERVAL_TRAINING','30 SECONDS WITH HIGH INTENSITY FOLLOWED BY 1-2 MINUTES OF LOW INTENSITY TRAINING FOR RECOVERY.','-','',10,8,'S'),(3,'ENDURANCE_CHALLENGE','SET A GOAL FOR A DISTANCE AND TRY TO ACHIEVE IT WITHIN A SPECIFIC TIME FRAME.','-',NULL,10,1,'S'),(4,'FULL_BODY_STRETCH','1-STAND WITH YOUR FEET HIP WIDTH APART. 2-REACH YOUR ARMS OVERHEAD AND EXTEND YOUR WHOLE BODY AND HOLD FOR 20-30 SECONDS.','-',NULL,11,1,'S'),(5,'SEATED_FORWARD_BEND','1-SIT WITH YOUR LEGS EXTENDED IN FRONT OF YOU. 2-REACH FOR YOUR TOES OR NEAR IT AND HOLD FOR 15-30 SECONDS.','-',NULL,11,1,'S'),(6,'DUMBBELL_GOBLET_SQUAT','1-HOLD THE WEIGHT INTO YOUR CHEST. 2-KEEP YOUR ELBOWS IN AND YOUR FEET SHOULD BE SLIGHTLY WIDER THAN SHOULDER WIDTH. 3-THEN GO DOWN KEEPING YOUR ELBOWS IN. 4-WHILE DOWN KEEP YOUR CHEST UP AND PUSH THROUGH YOUR HEELS TO RETURN TO STARTING POSITION.','-','',7,2,'S'),(7,'DUMBBELL_ROW_BILATERAL','1-GRAB THE DUMBBELL WITH BOTH HANDS. 2-HINGE FORWARD WHILE KEEPING A FLAT BACK. 3-PULL YOUR ELBOWS STRAIGHT BACK POINTING TOWARDS THE CEILING','-','',6,2,'S'),(8,'DUMBBELL_FORWARD_LUNGE','1-STAND WHILE KEEPING YOUR FEET HIP APART. 2-TAKE A BIG STEP FORWARD WHILE LOWERING YOUR HIPS UNTIL YOUR KNEE IS NEARLY REACHING THE GROUND WITHOUT TOUCHING IT AND YOUR THIGH IS PARALLEL WITH THE GROUND. 3-TO STAND UP PUSH THROUGH YOUR HEEL TO MAKE YOUR LEG STRAIGHT AND RETURN TO YOUR STARTING POSITION.','-','',7,2,'S'),(9,'DUMBBELL_OVERHEAD_PRESS','1-STAND AND KEEP YOUR FEET SHOULDER WIDTH APART AND KEEP YOUR BACK STRAIGHT. 2-PUT THE DUMBBELLS ABOVE YOUR SHOULDERS AND YOUR ELBOWS BENT. 3-PUSH UPWARDS AND EXTEND YOUR ARMS.','-','',2,2,'S'),(10,'CABLE_LAT_PRAYER','1-SET THE CABLE TO THE TOP OF THE MACHINE. 2-USE ANY ATTACHMENT AND GRAB IT AND TAKE A FEW STEPS BACK. 3-LEAN FORWARD WHILE PUSHING YOUR LOWER BODY BACK. 4-PUSH YOUR HIPS AND BRING THE ATTACHMENT TO IT.','-','',5,3,'S'),(11,'DUMBBELL_BENCH_PRESS','1-LAY FLAT ON A BENCH, 2-HOLD THE DUMBBELLS AT CHEST LEVEL, 3-PRESS THE DUMBBELLS UPWARD AND EXTEND YOUR ARMS','-','',1,2,'S'),(12,'BAND_PULL_APART','1-GRAB THE BAND AND POINT YOUR ARMS IN FRONT OF YOU AT SHOULDER LEVEL, 2-RETRACT BOTH YOUR SHOULDER BLADES AND JOINT UNTIL THE BAND TOUCHES YOUR CHEST','-','',2,6,'S'),(13,'DUMBBELL_ARNOLD_PRESS','1-STAND WITH THE DUMBBELLS AT NECK LEVEL AND YOUR PALMS FACING YOU, 2-PUSH UPWARDS WHILE ROTATING YOUR PALMS','-','',2,2,'S'),(14,'BODYWEIGHT_REVERSE_LUNGE','1-TAKE A BIG STEP backward, 2-BENT YOUR KNEE 90 DEGREES AND YOUR THIGHS SHOULD BE PARALLEL WITH THE GROUND, 3-PUSH THROUGH YOUR HEEL TO RETURN TO YOUR STARTING POSITION','-','',7,8,'S'),(15,'FOREARM_PLANK','1-PLACE YOUR FOREARMS ON THE GROUND WITH THE ELBOWS BENT AT 90 DEGREE. 2-TOUCH THE GROUND WITH YOUR TOES ONLY WHILE KEEPING YOUR FEET TOGETHER,3-LIFT YOUR STOMACH OFF THE FLOOR AND KEEP YOUR BODY AT STRAIGHT LINE','-',NULL,8,1,'S'),(16,'DECLINE_PUSH_UP','1-USE AN OBJECT TO ELEVATE YOUR FEET AND PLACE YOUR HANDS SLIGHTLY WIDER THAN SHOULDER WIDTH,2-LOWER YOUR BODY UNTIL YOUR CHEST NEARLY TOUCHES THE GROUND,3-RAISE YOUR BODY UNTIL ALMOST LOCKING YOUR ELBOWS','-','',1,8,'S'),(17,'SUPERMANS','1-LIE ON YOUR STOMACH WHILE ARMS FULLY EXTENDED IN FRONT OF YOU AND RAISE YOUR ARMS, LEGS AND CHEST AT THE SAME TIME AND HOLD. 2-SLOWLY LOWER THEM TO THE STARTING POSITION','-','',1,8,'S'),(18,'GLUTE_BRIDGE','1-LIE ON YOUR BACK WHILE KEEPING YOUR FEET FLAT ON THE FLOOR. 2-PUSH YOUR HIPS UPWARDS AND HOLD AT THE TOP. 3-SLOWLY RETURN TO THE STARTING POSITION','-','',1,8,'S'),(19,'BARBELL_BENCH_PRESS','1-LAY FLAT ON A BENCH,2-LOWER THE BAR TO CHEST LEVEL,3-RAISE THE BAR UPWARD AND EXTEND YOUR ARMS','-',NULL,1,1,'S'),(20,'BARBELL_REVERSE_LUNGE','1-STAND WITH THE BARBELL ON YOUR SHOULDER AND KEEP YOUR FEET HIP WIDTH APART. 2-TAKE A BIG STEP BACKWARDS AND BENT YOUR KNEE 90 DEGREES AND YOUR THIGHS SHOULD BE PARALLEL WITH THE GROUND,3-PUSH THROUGH YOUR HEEL TO RETURN TO YOUR STARTING POSITION','-',NULL,7,1,'S'),(21,'BARBELL_OVERHEAD_PRESS','1-STAND AND KEEP YOUR FEET SHOULDER WIDTH APART. 2-PUSH UPWARDS AND EXTEND YOUR ARMS. 3-RETURN TO THE STARTING POSITION SLOWLY WHILE CONTROLLING THE WEIGHT','-',NULL,2,1,'S'),(22,'BARBELL_SEATED_CALF_RAISE','1-SIT ON A BENCH AND PUT THE BARbell ON YOUR KNEES WHILE KEEPING YOUR FEET WIDTH APART. 2-HOLD THE BARBELL TO SUPPORT AND PUSH YOUR HEELS UPWARD AND HOLD FOR 1-2 SECONDS. 3- SLOWLY GET BACK TO THE STARTING POSITION','-',NULL,7,1,'S'),(23,'BARBELL_HIP_THRUST','1-SIT ON THE GROUND WHILE RESTING YOUR SHOULDERS ON A BENCH. 2-PUT THE BARbell ON YOUR HIP AND PUSH UPWARD','-',NULL,1,1,'S'),(24,'BARBELL_BENTOVER_ROW','1-BEND FORWARD WHILE KEEPING A FLAT BACK AND MAKE SURE TO GRAB THE BARbell AT SHOULDER WIDTH. 2-PULL TOWARDS YOUR STOMACH. 3- SLOWLY RETURN TO THE START POSITION','-',NULL,6,1,'S'),(25,'BARBELL_GOBLET_SQUAT','1-GRAB THE ATTACHMENT AND YOUR PALMS SHOULD FACE YOUR CHEST. 2-WALK BACK FEW STEPS. 3-KEEP YOUR ELBOWS BELOW THE BAR AND SQUAT UNTIL YOU REACH KNEE LEVEL. 4-GET BACK TO THE STARTING POSITION','-',NULL,7,1,'S'),(26,'CABLE_BENTOVER_BAR_PULLOVER','1-SET THE CABLE TO THE HIGHEST LEVEL ON THE MACHINE. 2-WALK BACK A FEW STEPS THEN LEAN FORWARD PULL THE ATTACHMENT TO YOUR HIP','-','',6,3,'S'),(27,'CABLE_PEC_FLY','1-SET THE MACHINE AT SHOULDER LEVEL. 2-GRAB THE HANDLES. 3-TAKE A STEP FORWARD WITH ONE LEG TO SUPPORT. 4-BRING THE HANDLES TOGETHER','-','',1,3,'S'),(28,'CABLE_30DEGREE_SHRUG','1-SET THE ATTACHEMNT TO THE LOWEST POINT. 2-GRAB THE HANDLES AND PULL UPWARDS','-','',6,3,'S'),(29,'CABLE_HAMSTRING_CURL','1-PLACE THE ATTACHMENT ON YOUR ANKLE AND SET IT TO THE LOWEST POINT ON THE MACHINE. 2-PULL YOUR ANKLE BACK. 3-REPEAT FOR THE OTHER LEG','-','',7,3,'S'),(30,'BAND_PULLOVER','1-PLACE THE BAND ABOVE HEAD LEVEL. 2-TAKE FEW STEPS BACK ABD BEND SLIGHTLY FORWARD. 3-BRING THE BAND TO YOUR HIP','-','',6,6,'S'),(31,'BAND_CRUNCH','1-PLACE THE BAND AT THE HIGHEST POINT AND SIT ON YOUR KNEES. 2-GRAB THE BAND AND BRING YOUR HEAD TO BELOW HIP LEVEL','-','',8,6,'S'),(32,'BAND_SINGLE_ARM_OVERHEAD_PRESS','1-LOOP THE BEND UNDER ONE OF YOUR FEETS. 2-GRAB THE OTHER END AND PUSH UPWARDS','-','',2,6,'S'),(33,'DUMBBELL_OVERHEAD_TRICEP_EXTENSION','1-PUT THE DUMBBELL BEHIND YOUR HEAD AND MAKE SURE YOUR ELBOWS ARE POINTING AT THE CEILING. 2-PUSH UPWARDS','-','',4,2,'S'),(34,'CABLE_CROSS_PUSHDOWN','1-HOLD EACH HANDLE WITH THE OPPOSING HAND. 2-EXTEND YOUR ELBOWS FULLY','-','',4,3,'S'),(35,'KETTLEBELL_SKULL_CRUSHER','1-LIE ON YOUR BACK. 2-HOLD THE KETTLEBELL ABOVE YOUR CHEST. 3-BRING IT UNTIL IT REACHES IN FRONT OF YOUR FOREHEAD','-','',4,5,'S'),(36,'KETTLEBELL_REVERSE_LUNGE','1-STAND STRAIGHT. 2-BRING ONE LEG BEHIND YOU AND SQUAT DOWN WHILE KEEPING A STRAIGHT BACK','-','',7,5,'S'),(37,'KETTLEBELL_SINGLE_ARM_ROW','1- STAND WITH YOUR FEET BEING SHOULDER WIDTH APART. \r\n2- PUT ONE LEG BEHIND YOU AND BEND FORWARD. \r\n3- LET YOUR ARM FREE THEN PULL THE KETTLEBELL TO YOUR CHEST','-','',6,5,'S'),(38,'KETTLEBELL_CONCENTRATION_CURL','1-SIT ON A BENCH AND HOLD THE KETTLEBELL WITH ONE HAND and THE other IS RESTING ON YOUR THIGH. 2-EXTEND YOUR ARM TOWARDS THE FLOOR. 3- BRING THE KETTLEBELL TO YOUR CHEST','-','',3,5,'S'),(39,'BARBELL_PAUSE_SQUAT','1-STAND WITH YOUR FEET ARE SHOULDER WIDTH APART. 2-SQUAT DOWN AND PAUSE FOR 1-2 SECONDS. 3-PUSH THROUGH YOUR HEELS TO GET BACK UP','-',NULL,7,1,'S'),(40,'BARBELL_LANDMINE_ROW','1-GRAB THE END OF THE BARBELL. 2-BEND KNEES UNTIL YOUR TORSO IS PARALLEL TO THE GROUND. 3-PULL THE BARBELL TOWARDS YOUR CHEST','-',NULL,6,1,'S'),(41,'BARBELL_UPRIGHT_ROW','1-GRAB THE BARBELL AT ABOUT SHOULDER WIDTH. 2-PULL YOUR ELBOWS UPWARDS UNTIL THE BAR REACHES NEAR YOUR CHIN','-','',2,8,'S'),(42,'BARBELL_CALF_JUMP','1-STAND WITH YOUR FEET SHOULDER WIDTH APART. 2-BEND YOUR KNEES SLIGHTLY. 3-MIMIC A JUMP MOTION WHILE KEEPING CONTACT WITH THE GROUND. 4-PAUSE AT THE TIPS OF YOUR TOES AND HOLD FOR A SECOND','-',NULL,7,1,'S'),(43,'BARBELL_CURL','1-STAND WITH YOUR CHEST UP AND A STRAIGHT BACK. 2-EXTEND YOUR ARMS TO THE FLOOR. 3-BRING THE BARBELL TO YOUR CHEST','-',NULL,3,1,'S'),(44,'BARBELL_SKULLCRUSHER','1-LIE ON YOUR BACK. 2-GRAB THE BARBELL AT SHOULDER WIDTH LEVEL ABOVE YOUR CHEST. 3-BRING THE BARBELL TO YOUR FOREHEAD WHILE KEEPING YOUR ELBOWS TUCKED IN','-',NULL,4,1,'S'),(45,'DUMBBELL_BULGARIAN_SPLIT_SQUAT','ELEVATE ONE LEG ON AN OBJECT THAT IS KNEE LEVEL. 2-SQUAT DOWN WHILE BENDING YOUR OTHER KNEE','-','',7,2,'S'),(46,'DUMBBELL_LAYING_REVERSE_FLY','1-SET THE BENCH AT 15-30 DEGREES AND LIE ON YOUR STOMACH. 2-BENT YOUR ELBOWS AND RAISE YOUR ARMS UNTIL IT REACHES SHOULDER LEVEL','-','',2,2,'S'),(47,'DUMBBELL_LATERAL_RAISE','1-BEND OVER SLIGHTLY WHILE KEEPING YOUR CHEST UP AND BEND YOUR ELBOWS SLIGHTLY. 2-RAISE YOUR ARMS UNTIL IT REACHES SHOULDER LEVEL','-','',2,2,'S'),(48,'DUMBBELL_ROMANIAN_DEADLIFT','1-WHILE STANDING PUSH YOUR LOWER BODY BACK. 2-WHEN YOU FEEL YOUR HAMSTRING STRETCH PUSH YOUR HIPS FORWARD TO STAND UP BUT DONT PUSH IT FULLY','-','',7,2,'S'),(49,'DUMBBELL_CALF_RAISE','STAND AT THE TIP OF YOUR TOES and PAUSE for A SECOND','-','',7,2,'S'),(50,'DUMBBELL_TWISTING_CURL','1-STAND WITH YOUR FEET SHOULDER WIDTH APART.\r\n 2-EXTEND YOUR ARMS WITH THE PALMS FACING YOUR SIDE AND ELBOWS BENT. \r\n3-CURL UPWARDS TO SHOULDER LEVEL WHILE ROTATING YOUR WRISTS','-','',3,2,'S'),(51,'DUMBBELL_SKULLCRUSHER','1-LIE ON YOUR BACK. 2- EXTEND YOUR ARMS TOWARDS THE CEILING WHILE THE PALMS ARE FACING EACH OTHER. 3-BRING THE DUMBBELLS TO NEAR EAR LEVEL','-','',4,2,'S'),(52,'Plate car drive','1-Inhale and brace your abdominals-2-Raise the arms vertically while keeping the elbows slightly bent 3-Once the arms are parallel with the floor, rotate the plate clockwise and counterclockwise. 4-Lower the plate back to the starting position.','-','',2,4,'S'),(57,'Arnold press','Grab a set of dumbbells and stand with your legs shoulder-width apart. Raise the dumbbells to shoulder height with your palms facing your body. Keep your back straight and bend your knees slightly. Slowly push the dumbbells above your head while rotating your wrists 180 degrees (so your palms face away from your body).','','',2,2,'S');
/*!40000 ALTER TABLE `workout_exercise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_frequency`
--

DROP TABLE IF EXISTS `workout_frequency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_frequency` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repetitions` smallint unsigned NOT NULL,
  `sets` smallint unsigned NOT NULL,
  `exercise_id` bigint NOT NULL,
  `schedule_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workout_frequency_exercise_id_002091f8_fk_workout_exercise_id` (`exercise_id`),
  KEY `workout_frequency_schedule_id_5316842b_fk_workout_schedule_id` (`schedule_id`),
  CONSTRAINT `workout_frequency_exercise_id_002091f8_fk_workout_exercise_id` FOREIGN KEY (`exercise_id`) REFERENCES `workout_exercise` (`id`),
  CONSTRAINT `workout_frequency_schedule_id_5316842b_fk_workout_schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `workout_schedule` (`id`),
  CONSTRAINT `workout_frequency_chk_2` CHECK ((`sets` >= 0)),
  CONSTRAINT `workout_frequency_repetitions_0d0cb53e_check` CHECK ((`repetitions` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_frequency`
--

LOCK TABLES `workout_frequency` WRITE;
/*!40000 ALTER TABLE `workout_frequency` DISABLE KEYS */;
INSERT INTO `workout_frequency` VALUES (1,10,3,1,1),(2,10,2,2,1),(3,8,3,3,1),(4,8,2,4,2),(5,8,2,5,2),(6,10,3,6,2),(7,10,2,7,3),(8,10,2,8,3),(9,8,3,9,3),(10,10,3,10,4),(11,8,2,11,4),(12,10,3,12,4),(13,10,2,13,5),(14,10,2,14,5),(15,10,3,15,5),(16,8,3,16,6),(17,10,2,17,6),(18,8,2,18,6),(19,11,3,19,7),(20,12,3,20,7),(21,12,3,21,7),(22,10,3,22,7),(23,10,3,23,8),(24,10,3,24,8),(25,12,3,25,8),(26,10,3,26,8),(27,12,3,27,9),(28,12,3,28,9),(29,12,3,29,9),(30,11,3,30,9),(31,11,3,31,10),(32,10,3,32,10),(33,12,3,33,10),(34,11,3,34,10),(35,15,4,35,11),(36,15,3,36,11),(37,15,3,37,11),(38,15,4,38,11),(39,15,4,39,11),(40,10,3,40,12),(41,10,3,41,12),(42,15,3,42,12),(43,15,4,43,12),(44,15,3,44,12),(45,15,4,45,12),(46,15,4,46,13),(47,10,4,47,13),(48,15,3,48,13),(49,15,3,49,13),(50,15,4,50,13),(51,15,3,51,13),(57,3,3,1,1);
/*!40000 ALTER TABLE `workout_frequency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_muscle`
--

DROP TABLE IF EXISTS `workout_muscle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_muscle` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `muscle_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_muscle`
--

LOCK TABLES `workout_muscle` WRITE;
/*!40000 ALTER TABLE `workout_muscle` DISABLE KEYS */;
INSERT INTO `workout_muscle` VALUES (1,'CHEST'),(2,'SHOULDERS'),(3,'BICEPS'),(4,'TRICEPS'),(5,'LATS'),(6,'BACK'),(7,'LEGS'),(8,'ABS'),(9,'FOREARMS'),(10,'CARDIO'),(11,'FULLBODY');
/*!40000 ALTER TABLE `workout_muscle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_schedule`
--

DROP TABLE IF EXISTS `workout_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `schedule_name` varchar(255) NOT NULL,
  `level` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_schedule`
--

LOCK TABLES `workout_schedule` WRITE;
/*!40000 ALTER TABLE `workout_schedule` DISABLE KEYS */;
INSERT INTO `workout_schedule` VALUES (1,'CARDIO','B'),(2,'STRETHCHES','B'),(3,'YOGA','B'),(4,'Beginner Dumbbell Workout','B'),(5,'Upper Body For Women','B'),(6,'Beginner Bodyweight Workout','B'),(7,'Intermediate Barbell Workout','I'),(8,'Intermediate Cable Workout','I'),(9,'Intermediate Band Workout','I'),(10,'Intermediate Triceps Workout','I'),(11,'Advanced Kettlebell Workout','A'),(12,'Advanced Dumbbell Workout','A'),(13,'Advanced Barbell Workout','A');
/*!40000 ALTER TABLE `workout_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_session`
--

DROP TABLE IF EXISTS `workout_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_session` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` datetime(6) NOT NULL,
  `schedule_id` bigint NOT NULL,
  `trainer_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workout_session_schedule_id_2066b25d_fk_workout_schedule_id` (`schedule_id`),
  KEY `workout_session_trainer_id_37810776_fk_workout_trainer_id` (`trainer_id`),
  CONSTRAINT `workout_session_schedule_id_2066b25d_fk_workout_schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `workout_schedule` (`id`),
  CONSTRAINT `workout_session_trainer_id_37810776_fk_workout_trainer_id` FOREIGN KEY (`trainer_id`) REFERENCES `workout_trainer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_session`
--

LOCK TABLES `workout_session` WRITE;
/*!40000 ALTER TABLE `workout_session` DISABLE KEYS */;
INSERT INTO `workout_session` VALUES (22,'2024-01-03 15:05:21.589567',1,53),(24,'2024-01-04 18:21:22.005326',11,54);
/*!40000 ALTER TABLE `workout_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workout_trainer`
--

DROP TABLE IF EXISTS `workout_trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workout_trainer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `experince` varchar(1) NOT NULL,
  `is_Injured` varchar(1) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`),
  CONSTRAINT `workout_trainer_user_id_02d664a5_fk_account_user_id` FOREIGN KEY (`user_id`) REFERENCES `account_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workout_trainer`
--

LOCK TABLES `workout_trainer` WRITE;
/*!40000 ALTER TABLE `workout_trainer` DISABLE KEYS */;
INSERT INTO `workout_trainer` VALUES (53,'Abdullah','abdullah@ku.com','2020-02-03','M','A','N',2),(54,'Ahmad','ahmad@ku.com','2024-01-03','M','B','Y',5);
/*!40000 ALTER TABLE `workout_trainer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-06  1:33:54
